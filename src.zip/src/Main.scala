/*
 * テキストファイルを引数に受ける。
 * 何桁目にコンマを入れるか指定する。
 * 区切り位置は別ファイルで指定
 *
 * */

import scala.io.Source
import java.io.PrintWriter
import java.io.FileOutputStream
import java.io.OutputStreamWriter

object Main {

  def main(args: Array[String]): Unit = {

    val startTime = System.currentTimeMillis()
    // 引数チェック
    try{
      argsCheck(args)
      
    }catch{
      case e: IllegalArgumentException => println(e.getMessage())
      sys.exit()
    }

    addComma(args(0))

    println(System.currentTimeMillis() - startTime + "msec")
  }
  
  // ToDo
  // -helpとかどうすんの？
  def argsCheck(args: Array[String]) = {
    require(args.length > 0, "引数の数が不正です。")
    if(args(0).contentEquals("-help")){
      println("TODO：helpを表示")
      sys.exit()
    }
    require(args(0).endsWith(".txt"), "一つ目の引数には .txtファイルを指定してください。")

    // sys.exit()
  }

  /*
   * テキストファイル一行読み込む。
   * 指定位置にカンマを入れる。
   * 別テキストに吐き出す。
   * */
  def addComma(txtname: String) = {
    // テキストファイルの読み込み
    val source = Source.fromFile(txtname)
    // どこで区切るかを指定したファイルの読み込み
    val comma_pos = Source.fromFile("comma_pos.txt")
    val positions = comma_pos.mkString.split(",")

    val out = new FileOutputStream("out.txt", true)
    val writer = new OutputStreamWriter(out)
    
    // 1行ずつ読み込み
    source.getLines().foreach(x => {
      var j = 0
      var temp = ""
      
      positions.foreach(i => {
        var k = i.toInt
        temp += x.subSequence(j, k + j) + ","
        j = j + k
      })
      
      // 最後のコンマを削除
      temp = temp.dropRight(1)
      
      // 書き出し
      writer.write(temp + "\r\n")

    })
    writer.close()

  }
}
